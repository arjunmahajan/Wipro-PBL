
public class ex_13 
{
	public static void main(String[] args)
	{
	  int flag = 0;
      System.out.println ("The prime numbers in between 10 and 99 are :");
      for(int i=10;i<=99;i++)
     {
          for(int j=2;j<i;j++)
          {
              if(i%j==0)
              {
                  flag = 0;
                  break;
              }
              else
                  flag=1;
          }
          if(flag==1)
              System.out.println(i);
      }
	}
}