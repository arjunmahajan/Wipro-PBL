
public class ex_12 
{
	public static void main(String[] args)
	{
		int num=7,flag=0;
		for(int i=2;i<=num/2;i++)
		{
			if(num%i==0)
				flag=1;
		}
		if(flag==0)
			System.out.println("The number is prime.");
		else
			System.out.println("The number is not prime.");
	}
}
