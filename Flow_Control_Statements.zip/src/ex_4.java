public class ex_4 
{
	public static void main(String[] args)
	{
		char a='x';
		char b='b';
		if(a<b)
			System.out.println(a+","+b);
		else
			System.out.println(b+", "+a);
	}
}
