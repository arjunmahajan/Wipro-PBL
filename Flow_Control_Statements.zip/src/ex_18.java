
public class ex_18 
{
	public static void main(String[] args)
	{
		int num = 110011, rev= 0, rem, originalInteger;
		originalInteger=num;
        while( num != 0 )
        {
            rem=num% 10;
            rev=rev*10+rem;
            num/=10;
        }
        if (originalInteger==rev)
            System.out.println(originalInteger + " is a palindrome.");
        else
            System.out.println(originalInteger + " is not a palindrome.");
	}
}
