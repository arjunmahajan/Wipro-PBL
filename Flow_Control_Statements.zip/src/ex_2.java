public class ex_2 
{
	public static void main(String[] args)
	{
		int n=233;
		if(n%2==0)
			System.out.println("The number is even");
		else
			System.out.println("The number is odd.");
	}
}
