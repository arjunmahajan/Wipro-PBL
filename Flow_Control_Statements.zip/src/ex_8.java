import java.util.*;
public class ex_8 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the color code: ");
		char ch=sc.next().charAt(0);
		switch(ch)
		{
			case 'R':
				System.out.println("Red");
				break;
			case 'B':
				System.out.println("Blue");
				break;
			case 'G':
				System.out.println("Green");
				break;
			case 'Y':
				System.out.println("White");
			default:
				System.out.println("Invalid Code");
		}
		sc.close();
	}
}
