
public class ex_15
{
	public static void main(String[] args)
	{
		int n=1234,s=0,sum=0;
		while(n>0)
        {
            s=n%10;
            sum=sum+s;
            n=n/10;
        }
		System.out.println("The sum of values of integer is: "+sum);
	}
}
