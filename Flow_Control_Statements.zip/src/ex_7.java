
public class ex_7
{	
	public static void main(String[] args)
	{
		char x='A';
		if(Character.isLowerCase(x))
		{
			System.out.println(Character.toUpperCase(x));
		}
		else
		{
			System.out.println(Character.toLowerCase(x));
		}
	}

}
