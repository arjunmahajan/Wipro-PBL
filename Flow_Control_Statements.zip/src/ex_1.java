public class ex_1 
{
	public static void main(String[] args)
	{
		int n=-4;
		if(n>0)
			System.out.println("The number is positive.");
		else if(n<0)
			System.out.println("The number is negative.");
		else
			System.out.println("The number is zero.");
	}
}
