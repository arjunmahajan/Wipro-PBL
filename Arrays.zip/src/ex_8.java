public class ex_8 
{
		public static void main(String[] args)
		{
			int arr[] = {10,20,10,30,40,100,99}; 
			int max = 0;
			int ele=0;
			for (int i = 0; i < arr.length; i++) 
			{
			    int count = 0;
			    for (int j = 0; j < arr.length; j++)
			   {
			        if (arr[i]==arr[j])
			           count++;
			   }
			  if (count >= max)
			  {
			      max = count;
			      ele=arr[i];
			}
			}
			System.out.println(ele);
		}
	}


