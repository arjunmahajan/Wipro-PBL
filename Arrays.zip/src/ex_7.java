public class ex_7 
{	
	public static void main(String[] args)
	{
		int[] arr= {12,34,12,45,67,89};
		int[] arr2=new int[arr.length];
		int c=0,count=0;
		for(int i=0;i<arr.length;i++)
		{
			
			for(int j=0;j<arr.length;j++)
			{
				if(arr[i]==arr2[j])			
					count=1;
			}			
			if(count==0)
			{
				arr2[c]=arr[i];
				c++;
			}
			count=0;
			
		}
		for(int i=0;i<c;i++)
			System.out.print(arr2[i]+"    ");
	}
}
