import java.util.Arrays;
import java.util.Scanner;

public class ex_6 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=0;
		System.out.println("Enter the number of elements of array: ");
		n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the numbers: ");
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		Arrays.sort(arr);
		for(int i=0;i<n;i++)
			System.out.print(arr[i]+"    ");
		sc.close();
	}
}
