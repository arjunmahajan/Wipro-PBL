public class ex_9
{
	public static void main(String[] args)
	{
		int[] arr= {1,6,4,7,9};
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==6)
			{
				for(int j=i;j<arr.length;j++)
				{
					if(arr[j]==7)
					{
					   i=j+1;
					   break;
					}
				}
			}
			sum+=arr[i];			
		}
		System.out.println(sum);
	}
}
