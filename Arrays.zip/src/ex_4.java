public class ex_4 
{
	public static void main(String[] args)
	{
		int []arr=new int[256];
		char ch;
		for(int i=0;i<256;i++)
		{
			arr[i]=i;
			ch=(char)arr[i];
			System.out.print(ch);
		}
		
		
	}
}
