import java.util.*;
public class ex_3
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int i,num=0,count=0;	
		System.out.print("Enter the number to be searched: ");
		num=sc.nextInt();
		int arr[]= {11,14,15,50,35,23,65,34,50,93,41,64};
		for(i=0;i<arr.length;i++)
		{
			if(num==arr[i])
			{
				count=1;
				break;
			}
			else
				count=0;
		}
		if(count==1)
			System.out.println(i+1);
		else
			System.out.println("-1");
		sc.close();
	}
}
