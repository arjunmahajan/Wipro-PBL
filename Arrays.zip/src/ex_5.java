import java.util.*;
public class ex_5 
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n=0;
		System.out.println("Enter the number of elements of array: ");
		n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the numbers: ");
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		Arrays.sort(arr);
		System.out.println("The largest two numbers are: "+arr[arr.length-2]+", "+arr[arr.length-1]);
		System.out.print("The smallest two numbers are: "+arr[0]+", "+arr[1]);
		sc.close();
	}
}